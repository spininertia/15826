#!/bin/bash

# Output the answer to question 1
echo "Q4.1"
python edit_dist.py "The quick brown fox jumps over the lazy dog" "Das quik brown foxxx jumps over the lay-z dogg" 1 0.5

# Output the answer to questoin 2
echo "Q4.2"
python edit_dist.py "The quick brown fox jumps over the lazy dog" "Das quik brown foxxx jumps over the lay-z dogg" 0.5 5

# Output the answer to an arbitrary input
echo "Extra:"
python edit_dist.py "$1" "$2" $3 $4
