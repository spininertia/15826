-- Find the number of edges (the number of one hop connections)
select count(*) from edges;
